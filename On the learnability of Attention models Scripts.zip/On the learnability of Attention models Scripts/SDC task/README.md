This directory contain three files to run SDC task for CIFAR10 and CIFAR100 base datsets for all three algorithms

To change the number of patches and number of training points change following lines in each file

SA_HA_LVML_CIFAR10_script.py : to run different settings and algorithm for cifar10 data change line number  - 25 to 34

SA_HA_LVML_CIFAR100_script.py : to run different settings and algorithm for cifar100 data change line number  - 25 to 34
