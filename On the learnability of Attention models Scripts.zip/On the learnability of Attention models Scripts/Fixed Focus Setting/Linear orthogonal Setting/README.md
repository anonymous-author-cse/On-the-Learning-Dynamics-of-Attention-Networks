This directory contain three files to run experiments on fixed focus setting for linear orthogonal dataset, it will save the plots in same directory.

To change the number of patches and number of training points change following lines in each file

Hard Attention.py line 55-65

Soft Attention.py line 54-64

LVML.py  line 55-64
