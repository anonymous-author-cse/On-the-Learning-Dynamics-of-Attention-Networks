This directory contain three files to run experiments on fixed focus setting for cifar100 dataset, it will save the plots in same directory.

To change the number of patches and number of training points change following lines in each file

Hard Attention.py line 60-75

Soft Attention.py line 61-72

LVML.py  line 61-75
