This directory contain three files to run experiments on fixed focus setting for cifar10 dataset, it will save the plots in same directory.

To change the number of patches and number of training points change following lines in each file

Hard Attention.py line 54-69

Soft Attention.py line 53-66

LVML.py  line 54-66
