This directory contain  file to simulate diffential equation solutions.
To run different settings such number of patches and number of classes 
change line number 69,70 and 71 (as number of patches and classes increases number of steps needs to increase)

