This directory contain three files to generate heatmaps from saved models, it will save the heatmaps in same directory.

To change the number of patches and number of training points change following lines in each file

Generate_heatmaps_hard_attention.py line 38-45

Generate_heatmaps_soft_attention.py line 39-45

Generate_heatmaps_LVML_attention.py  line 38-45
